# TEUM / 틈 — Integrated Workspace

Dev1(TourAPI/Auth) + Dev2(Planner/Kakao/Recommendation/Timeline/Save)를 병합한 통합본입니다.
추가로 **회원가입 후 최초 여행 취향 설문 → 저장된 취향 + 이번 여행 조건 기반 개인화 추천**을 연결했습니다.

## 빠른 시작

### 1) 통합 키 설정
PowerShell:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\setup-integrated-keys.ps1
```

입력:
- Kakao REST API key
- Kakao JavaScript key
- TourAPI Decoding key

생성되는 로컬 전용 파일:
- `.env.local`
- `js/config/keys.local.js`

실제 키는 ZIP/Git에 포함하지 않습니다.

### 2) 자동 검사

```powershell
npm run check
```

### 3) 실행

```powershell
npm run dev
```

브라우저:

```text
http://localhost:4173/index.html
```

### 4) API smoke
다른 터미널에서:

```powershell
npm run smoke:kakao
npm run smoke:tour
```

---

## 주요 사용자 흐름

### 신규 사용자

```text
회원가입
→ 자동 로그인
→ 최초 여행 취향 설문
→ HOME
→ 이번 여행 조건 입력
→ 개인화 Slow / Full / Random
→ 상세 / 숙소 선택 / 저장
```

### 기존 사용자

```text
로그인
→ 저장된 여행 취향 확인
→ HOME
→ 출발지 / 시간 / 기간 / 교통 / 이번 여행 분위기 입력
→ 개인화 추천
```

### 취향 수정

```text
MY
→ 여행 취향
→ 여행 취향 수정하기
→ 설문 수정
→ 이후 추천부터 반영
```

---

## 통합된 기능

### Dev1
- F101 지역별 관광지
- F102 관광/숙박/음식
- F103 문화/행사/코스/쇼핑
- TourAPI `detailCommon2 + detailIntro2`
- F107 회원관리
- F108 로그인/로그아웃

### Dev2
- 출발지: GPS / 주소·장소 / 빠른 위치 / 좌표
- 당일 / 1박2일
- 대중교통 / 자차
- Slow / Full / Random
- 귀가시간 Hard Gate
- Kakao Route fallback/diagnostics
- Kakao Map marker info
- 1박2일 숙소 최대 5곳 일정 대입 검증
- 일정 저장/삭제

### Integration personalization
- `teum.user_preferences.v1`
- 최초 6-step 여행 취향 설문
- Long-term Preference + Trip Context Resolver
- 개인화 Candidate Ranking
- 사용자의 pace에 따른 일정 밀도 보정
- 현재 mood는 "이번 여행에서만" temporary override
- Result에서 추천 이유 표시
- MyPage에서 취향 수정

---

## 실제 장소 Provider

Recommendation은 더 이상 MockPlaceProvider를 사용하지 않습니다.

```js
import { placeProvider } from './js/integration/placeProvider.js';
```

Integration adapter는 Dev1 TourAPI를 그대로 사용하되 음식/숙박 후보를 **현재 위치 기반**으로 조회하도록 보정합니다.
추천 엔진은 TourAPI raw response를 직접 읽지 않고 normalized `Place` contract만 사용합니다.

---

## 저장 정책

현재 통합 기본 정책:
- 로그인 사용자: `ownerUserId = currentUser.id`
- 비로그인: 기존 Dev2 동작을 보존해 guest save 허용
- 저장 목록은 현재 사용자 ID 기준으로 분리
- 비로그인은 `ownerUserId: null`인 guest 저장만 표시
- 회원 탈퇴 시 해당 사용자의 Preference + 저장 여행도 함께 정리

정책은 `js/integration/tripAuthBridge.js`에서 바꿀 수 있습니다.

---

## 테스트 명령

```powershell
npm run check
npm run test:dev1
npm run test:dev2
npm run test:integration
npm run test:auth-preference
npm run smoke:kakao
npm run smoke:tour
```

자세한 내용:
- `INTEGRATION_REPORT.md`
- `INTEGRATED_QA_CHECKLIST.md`
- `RUN_INTEGRATED.md`
- `docs/DEV1_REPORT_FINAL.md`
- `DEV2_REPORT.md`
